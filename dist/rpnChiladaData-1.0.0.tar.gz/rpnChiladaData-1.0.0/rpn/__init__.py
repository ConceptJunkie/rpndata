#!/usr/bin/env python

# //******************************************************************************
# //
# //  __init__.py
# //
# //  RPN command-line calculator
# //  copyright (c) 2019, Rick Gutleber (rickg@his.com)
# //
# //  License: GNU GPL 3.0 (see <http://www.gnu.org/licenses/gpl.html> for more
# //  information).
# //
# //******************************************************************************

__import__( 'pkg_resources' ).declare_namespace( __name__ )

